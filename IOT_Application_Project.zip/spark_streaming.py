
from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, FloatType

# Initialize Spark Session
spark = SparkSession.builder \
    .appName("WeatherDataStreaming") \
    .config("spark.master", "local[*]") \
    .getOrCreate()

# Kafka parameters
kafka_bootstrap_servers = "localhost:9092"  # Replace with your Kafka broker address
kafka_topic = "weather-data"

# Define the schema for incoming JSON data
weather_schema = StructType() \
    .add("city", StringType()) \
    .add("temperature", FloatType()) \
    .add("humidity", FloatType()) \
    .add("description", StringType())

# Read data from Kafka topic as a DataFrame
weather_stream = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", kafka_bootstrap_servers) \
    .option("subscribe", kafka_topic) \
    .option("startingOffsets", "earliest") \
    .load()

# Deserialize the JSON data
weather_data = weather_stream.selectExpr("CAST(value AS STRING)") \
    .select(from_json(col("value"), weather_schema).alias("data")) \
    .select("data.*")  # Flatten nested structure

# Process data (example: filter or aggregate)
processed_data = weather_data.withColumn("temperature_F", col("temperature") * 9/5 + 32)  # Convert to Fahrenheit

# Write the output to the console (for debugging purposes)
query = processed_data.writeStream \
    .outputMode("append") \
    .format("console") \
    .option("truncate", "false") \
    .start()

# Await termination
query.awaitTermination()
    