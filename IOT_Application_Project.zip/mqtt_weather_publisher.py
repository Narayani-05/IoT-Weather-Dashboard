
import requests
import json
import paho.mqtt.client as mqtt
import time

# OpenWeatherMap API details
api_key = "your_api_key_here"
city = "London"
weather_url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"

# MQTT Broker details
mqtt_broker = "mqtt.eclipseprojects.io"  # Use your MQTT broker address
mqtt_port = 1883  # Default MQTT port
mqtt_topic = "weather/data"  # Topic to publish weather data

# Initialize MQTT client
client = mqtt.Client()
client.connect(mqtt_broker, mqtt_port)

# Function to fetch and publish weather data
def fetch_and_publish_weather():
    try:
        # Fetch weather data from OpenWeatherMap
        response = requests.get(weather_url)
        response.raise_for_status()  # Raise HTTPError for bad responses

        # Parse the JSON response
        weather_data = response.json()
        formatted_data = {
            "city": weather_data["name"],
            "temperature": weather_data["main"]["temp"],
            "humidity": weather_data["main"]["humidity"],
            "description": weather_data["weather"][0]["description"],
            "wind_speed": weather_data["wind"]["speed"]
        }

        # Convert data to JSON string
        weather_json = json.dumps(formatted_data)

        # Publish to MQTT topic
        client.publish(mqtt_topic, weather_json)
        print(f"Published: {weather_json}")

    except requests.exceptions.HTTPError as err:
        print(f"HTTP error occurred: {err}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Continuous publishing every 10 minutes
while True:
    fetch_and_publish_weather()
    time.sleep(600)  # 600 seconds = 10 minutes
    