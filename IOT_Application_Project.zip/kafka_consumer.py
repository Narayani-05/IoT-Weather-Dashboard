
from kafka import KafkaConsumer
import json

# Kafka broker details
kafka_topic = "weather-data"
bootstrap_servers = ["localhost:9092"]  # Replace with your Kafka broker address

# Initialize Kafka Consumer
consumer = KafkaConsumer(
    kafka_topic,
    bootstrap_servers=bootstrap_servers,
    value_deserializer=lambda x: json.loads(x.decode('utf-8')),  # Deserialize JSON messages
    auto_offset_reset='earliest',  # Start reading at the earliest message
    group_id='weather_consumer_group'  # Consumer group ID
)

print(f"Consuming messages from topic: {kafka_topic}")
# Process messages from Kafka
for message in consumer:
    weather_data = message.value
    print(f"Received weather data: {weather_data}")

    # Example: Access specific fields
    city = weather_data.get("city")
    temperature = weather_data.get("temperature")
    humidity = weather_data.get("humidity")

    print(f"City: {city}, Temperature: {temperature}°C, Humidity: {humidity}%")
    