
import requests
import json

# Your API key (replace with your actual key)
api_key = "your_api_key_here"
# City for which to fetch the weather
city = "London"
# API endpoint URL
url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"

# Make the request
response = requests.get(url)
# Check if the request was successful
if response.status_code == 200:
    # Parse JSON data
    weather_data = response.json()
    print(json.dumps(weather_data, indent=4))  # Pretty print the JSON
else:
    print("Failed to retrieve data:", response.status_code)
    